class QueryPath(object):
    """"""

    def __init__(self, path, queried_prop):
        """"""

        self.path = path
        self.queried_prop = queried_prop
