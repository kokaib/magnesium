from abc import ABC, abstractmethod


class BaseExtractor(ABC):
    """"""
    
    def extract(self, data):
        """"""
