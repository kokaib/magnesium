from abc import ABC, abstractmethod


class BasePathProcessor(ABC):
    """"""
    
    @abstractmethod
    def process(self, x):
        """"""
