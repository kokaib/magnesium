from abc import ABC, abstractmethod


class BasePrefab(ABC):
    """"""

    @abstractmethod
    def execute(self, sample_data):
        """"""
