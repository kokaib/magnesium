from abc import ABC, abstractmethod


class BasePipelineBuilder(ABC):
    """"""

    @abstractmethod
    def build(self):
        """"""
