# Magnesium

Magnesium aims to abstract away the complexity of finding
the right elements in an element tree and extracting their
data.
